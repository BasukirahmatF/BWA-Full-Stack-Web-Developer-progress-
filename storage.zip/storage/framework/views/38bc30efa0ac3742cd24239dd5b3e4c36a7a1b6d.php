<link 

  rel="stylesheet" href="<?php echo e(url('frontend/libraries/bootstrap/css/bootstrap.css')); ?>" 
/>
<link
href="https://fonts.googleapis.com/css?family=Assistant:200,400,700&&display=swap"
rel="stylesheet"
/>
<link
  href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700&display=swap"
  rel="stylesheet"
/>
<link rel="stylesheet" href="<?php echo e(url('frontend/styles/main.css')); ?>" /><?php /**PATH D:\belajar-laravel\nomads\resources\views/includes/style.blade.php ENDPATH**/ ?>